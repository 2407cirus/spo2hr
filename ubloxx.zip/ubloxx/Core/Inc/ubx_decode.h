#ifndef UBX_DECODE_H
#define UBX_DECODE_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* ================= CHECKSUM ================= */
typedef struct {
    uint8_t ck_a;
    uint8_t ck_b;
} ubx_checksum_t;

ubx_checksum_t ubx_compute_checksum(
    const uint8_t *data,
    size_t start,
    size_t length
);

/* ================= LITTLE ENDIAN READERS ================= */
uint32_t readU4LE(const uint8_t *p, size_t o);
uint16_t readU2LE(const uint8_t *p, size_t o);
int32_t  readI4LE(const uint8_t *p, size_t o);
int16_t  readI2LE(const uint8_t *p, size_t o);

/* ================= UBX DECODERS ================= */
void decodeSecSigV2(const uint8_t *payload, size_t len);
void decodeSecOSNMA(const uint8_t *payload, size_t len);
void decodeMonCOMMS(const uint8_t *p, size_t len);
void decodeNavDOP(const uint8_t *p, size_t len);
void decodeNavGEOFENCE(const uint8_t *p, size_t len);
void decodeRxmCOR(const uint8_t *p, size_t len);
void decodeNavSAT(const uint8_t *p, size_t len);
void decodeNavStatus(const uint8_t *p, size_t len);
void decodeNavTimeUTC(const uint8_t *p, size_t len);
void decodeNavPVT(const uint8_t *p, size_t len);

/* ================= HELPERS ================= */
void decodeTimeUTCFlags(uint8_t v);
void decodeValidFlags(uint8_t v);

#endif /* UBX_DECODE_H */
