#include "ubx_decode.h"
#include "main.h"
#include <stdarg.h>   // <-- REQUIRED for va_list
#include <stdio.h>    // <-- REQUIRED for vsnprintf
#include <string.h>   // <-- REQUIRED for strlen
extern UART_HandleTypeDef huart2;

static void uart_printf(const char *fmt, ...)
{
    char buf[160];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    HAL_UART_Transmit(&huart2, (uint8_t *)buf, strlen(buf), HAL_MAX_DELAY);
}

static void print_uart(const char *fmt, ...)
{
    char buf[128];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    HAL_UART_Transmit(&huart2, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
}

/* ================= CHECKSUM ================= */
ubx_checksum_t ubx_compute_checksum(
    const uint8_t *data,
    size_t start,
    size_t length
) {
    ubx_checksum_t cs = {0, 0};

    for (size_t i = start; i < start + length; i++) {
        cs.ck_a += data[i];
        cs.ck_b += cs.ck_a;
    }
    return cs;
}

/* ================= LITTLE ENDIAN READERS ================= */
uint32_t readU4LE(const uint8_t *p, size_t o) {
    return  (uint32_t)p[o] |
           ((uint32_t)p[o+1] << 8) |
           ((uint32_t)p[o+2] << 16) |
           ((uint32_t)p[o+3] << 24);
}

uint16_t readU2LE(const uint8_t *p, size_t o) {
    return (uint16_t)(p[o] | (p[o+1] << 8));
}

int32_t readI4LE(const uint8_t *p, size_t o) {
    return (int32_t)readU4LE(p, o);
}

int16_t readI2LE(const uint8_t *p, size_t o) {
    return (int16_t)readU2LE(p, o);
}

/* ================= SEC-SIG-V2 ================= */
void decodeSecSigV2(const uint8_t *p, size_t len)
{
    if (len < 4) return;

    uint8_t version = p[0];

    uint8_t sigSecFlags = p[1];
    uint8_t jamDetEnabled  = sigSecFlags & 0x01;
    uint8_t jammingState   = (sigSecFlags >> 1) & 0x03;
    uint8_t spoofDetEnabled= (sigSecFlags >> 3) & 0x01;
    uint8_t spoofingState  = (sigSecFlags >> 4) & 0x07;

    uart_printf("\r\nSEC-SIG v%d\r\n", version);
    uart_printf("JamEn=%d JamState=%d SpoofEn=%d SpoofState=%d\r\n",
                jamDetEnabled,
                jammingState,
                spoofDetEnabled,
                spoofingState);
}

/* ================= SEC-OSNMA ================= */
void decodeSecOSNMA(const uint8_t *p, size_t len)
{
    if (len < 4) return;

    uint8_t version = p[0];
    if (version != 3) return;   // X20 uses v3

    uint8_t nmaHeader = p[1];
    uint8_t authStatus = nmaHeader & 0x01;
    uint8_t nmaStatus  = (nmaHeader >> 1) & 0x03;

    uint8_t mon = p[2];
    uint8_t osnmaEnabled = mon & 0x01;
    uint8_t numSVs = (mon >> 1) & 0x1F;

    uart_printf("\r\nSEC-OSNMA\r\n");
    uart_printf("AuthStatus: %d  NMAStatus: %d\r\n", authStatus, nmaStatus);
    uart_printf("Enabled: %d  SVs: %d\r\n", osnmaEnabled, numSVs);

    size_t offset = 4;
    for (uint8_t i = 0; i < numSVs; i++)
    {
        if (offset + 4 > len) break;

        uint16_t info = p[offset] | (p[offset+1] << 8);
        uint8_t svid = p[offset+2];

        uart_printf("SV %d  IODE=%u  Auth=%d\r\n",
                    svid, info & 0x3FF, (info >> 15) & 0x01);

        offset += 4;
    }
}

/* ================= MON-COMMS ================= */
void decodeMonCOMMS(const uint8_t *p, size_t len)
{
    if (len < 8) return;

    uint8_t nPorts = p[1];
    uart_printf("\r\nMON-COMMS\r\n");
    uart_printf("Ports: %d\r\n", nPorts);

    size_t offset = 8;

    for (uint8_t i = 0; i < nPorts; i++)
    {
        if (offset + 40 > len) break;

        uint16_t portId = readU2LE(p, offset);
        uint32_t txBytes = readU4LE(p, offset + 4);
        uint32_t rxBytes = readU4LE(p, offset + 12);

        uart_printf("Port %u  TX=%lu  RX=%lu\r\n",
                    portId, txBytes, rxBytes);

        offset += 40;
    }
}


/* ================= NAV-DOP ================= */
void decodeNavDOP(const uint8_t *p, size_t len)
{
    if (len != 18) return;

    uart_printf("\r\nNAV-DOP\r\n");
    uart_printf("GDOP=%u  PDOP=%u  HDOP=%u  VDOP=%u\r\n",
        readU2LE(p, 4),
        readU2LE(p, 6),
        readU2LE(p, 12),
        readU2LE(p, 10));
}


/* ================= NAV-GEOFENCE ================= */
void decodeNavGEOFENCE(const uint8_t *p, size_t len)
{
    if (len < 8) return;

    uint8_t num = p[6];
    uint8_t combState = p[7];

    uart_printf("\r\nNAV-GEOFENCE\r\n");
    uart_printf("Fences: %d  CombinedState: %d\r\n", num, combState);

    size_t offset = 8;
    for (uint8_t i = 0; i < num; i++)
    {
        if (offset + 2 > len) break;
        uart_printf("Fence %d  State=%d\r\n", p[offset+1], p[offset]);
        offset += 2;
    }
}

/* ================= RXM-COR ================= */
void decodeRxmCOR(const uint8_t *p, size_t len)
{
    if (len != 12) return;

    uint32_t status = readU4LE(p, 4);

    uart_printf("\r\nRXM-COR\r\n");
    uart_printf("Protocol=%lu  Err=%lu  MsgUsed=%lu\r\n",
        status & 0x1F,
        (status >> 6) & 0x03,
        (status >> 8) & 0xFFFF);
}


/* ================= NAV-SAT ================= */
void decodeNavSAT(const uint8_t *p, size_t len)
{
    if (len < 8) return;

    uint8_t numSVs = p[5];
    uart_printf("\r\nNAV-SAT  SVs=%d\r\n", numSVs);

    size_t offset = 8;
    for (uint8_t i = 0; i < numSVs; i++)
    {
        if (offset + 12 > len) break;

        uint8_t svid = p[offset+1];
        uint8_t cno  = p[offset+2];
        int8_t elev  = (int8_t)p[offset+3];

        uart_printf("SV %d  C/N0=%d  Elev=%d\r\n",
                    svid, cno, elev);

        offset += 12;
    }
}


/* ================= NAV-STATUS ================= */
void decodeNavStatus(const uint8_t *p, size_t len)
{
    if (len != 16) return;

    uint8_t fix = p[4];
    uint8_t flags = p[5];

    uart_printf("\r\nNAV-STATUS\r\n");
    uart_printf("Fix=%d  FixOK=%d  Diff=%d\r\n",
                fix,
                flags & 0x01,
                (flags >> 1) & 0x01);
}


/* ================= NAV-TIMEUTC ================= */
void decodeNavTimeUTC(const uint8_t *p, size_t len)
{
    if (len != 20) return;

    uart_printf("\r\nNAV-TIMEUTC\r\n");
    uart_printf("%u-%02u-%02u %02u:%02u:%02u\r\n",
        readU2LE(p,12), p[14], p[15],
        p[16], p[17], p[18]);
}

//void decodeNavTimeUTC(const uint8_t *p, size_t len) {
//    if (len != 20) return;
//}

/* ================= NAV-PVT ================= */
void decodeValidFlags(uint8_t v) {
    (void)v;
}

void decodeNavPVT(const uint8_t *p, size_t len)
{
    if (len != 92) return;

    int32_t lon = readI4LE(p, 24);   // 1e-7 deg
    int32_t lat = readI4LE(p, 28);   // 1e-7 deg
    int32_t height = readI4LE(p, 32); // mm
    uint8_t numSV = p[23];

    print_uart("\r\nNAV-PVT\r\n");

    print_uart("Lat: %ld.%07ld\r\n",
               lat / 10000000,
               labs(lat % 10000000));

    print_uart("Lon: %ld.%07ld\r\n",
               lon / 10000000,
               labs(lon % 10000000));

    print_uart("Height: %ld.%03ld m\r\n",
               height / 1000,
               labs(height % 1000));

    print_uart("SVs: %d\r\n", numSV);
}

