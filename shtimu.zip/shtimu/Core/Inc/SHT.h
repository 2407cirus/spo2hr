/*
 * SHT.h
 *
 *  Created on: Sep 11, 2025
 *      Author: R9
 */

#ifndef INC_SHT_H_
#define INC_SHT_H_


#include <stdint.h>
#include <stddef.h>


#define SHT40_NOK		(0x00)
#define	SHT40_OK		(0x01)
#define SHT40_I2CH_R	(0x02)
#define	SHT40_I2CH_W	(0x03)
#define	SHT40_OLD_DATA	(0x04)
#define SHT40_NAK		(0x15)

#define	I2C_ADDR_SHT40_AD	(0x44)
#define	I2C_ADDR_SHT40_B	(0x45)

#define SHT40_SN		(0x89)
#define	SHT40_RST		(0x94)

#define SHT40_UNIT_POS	0
#define SHT40_UNIT_MASK	0b00000001
#define SHT40_UNIT		(1 << SHT40_OLD_TEMP_POS)

#define	SHT40_OLD_TEMP_POS	1
#define	SHT40_OLD_TEMP_MASK	0b00000010
#define SHT40_OLD_TEMP		(1 << SHT40_OLD_TEMP_POS)

#define SHT40_OLD_RH_POS	2
#define SHT40_OLD_RH_MASK	0b00000100
#define SHT40_OLD_RH		(1 << SHT40_OLD_RH_POS)


typedef enum {
	TRH_H = 0xFD,
	TRH_M = 0xF6,
	TRH_L = 0xE0,
	TRH_H_H02W1S = 0x39,
	TRH_H_H02W01S = 0x32,
	TRH_H_H011W01S = 0x2F,
	TRH_H_H011W1S = 0x24,
	TRH_H_H002W1S = 0x1E,
	TRH_H_H002W01S = 0x15
} SHT40_meas_t;

typedef enum {
	SHT40_UNIT_C = (0 << SHT40_UNIT_POS),
	SHT40_UNIT_F = (1 << SHT40_UNIT_POS)
} SHT40_unit_t ;


typedef void (*extI2C)(uint8_t addr, uint8_t* data, uint8_t len, uint16_t delay);


// ----- STRUCT
typedef struct {
    union {
        uint8_t header;
        struct {
            uint16_t sn2;
            uint8_t crc2;
            uint16_t sn1;
            uint8_t crc1;
        } __attribute__((packed, aligned(1))) snData;

        struct {
            uint8_t temp[2];
            uint8_t crc2;
            uint8_t rh[2];
            uint8_t crc1;
        } __attribute__((packed, aligned(1))) mData;
    };

    uint8_t address;
    extI2C I2CRead;
    extI2C I2CWrite;
    uint8_t controlReg;
} SHT40;


// ----- API FUNCTIONS
void SHT40_initStruct(SHT40 *dev, uint8_t addr, extI2C i2cr, extI2C i2cw);
void SHT40_deinitStruct(SHT40 *dev);

uint8_t SHT40_measure(SHT40 *dev, SHT40_meas_t type);
uint8_t SHT40_temperature(SHT40 *dev, int8_t *out);
uint8_t SHT40_rh(SHT40 *dev, uint8_t *out);
uint32_t SHT40_whoAmI(SHT40 *dev);
void SHT40_reset(const SHT40 *dev);
uint8_t SHT40_begin(SHT40 *dev, SHT40_unit_t u);

void SHT40_setUnit(SHT40 *dev, SHT40_unit_t unit);
SHT40_unit_t SHT40_getUnit(const SHT40 *dev);
void SHT40_clear(SHT40 *dev);





#endif /* INC_SHT_H_ */
