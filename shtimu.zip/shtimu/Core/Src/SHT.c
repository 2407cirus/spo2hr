/*
 * SHT.c
 *
 *  Created on: Sep 11, 2025
 *      Author: R9
 */


#include "SHT.h"
#include <string.h>

// ----- STATIC FUNCTION DECLARATIONS
static uint16_t getMeasureDelay(SHT40_meas_t type);


// ----- FUNCTIONS IMPLEMENTATION
void SHT40_initStruct(SHT40 *dev, uint8_t addr, extI2C i2cr, extI2C i2cw)
{
    dev->address = addr;
    dev->I2CRead = i2cr;
    dev->I2CWrite = i2cw;
    dev->controlReg = 0;

    SHT40_setUnit(dev, SHT40_UNIT_C);
    SHT40_clear(dev);
}

void SHT40_deinitStruct(SHT40 *dev)
{
    dev->address = 0x00;
    dev->I2CRead = NULL;
    dev->I2CWrite = NULL;
    dev->controlReg = 0;
    SHT40_clear(dev);
}

uint8_t SHT40_measure(SHT40 *dev, SHT40_meas_t type)
{
    dev->I2CWrite(dev->address, (uint8_t*)&type, 1, getMeasureDelay(type));
    dev->I2CRead(dev->address, (uint8_t*)&dev->mData, 6, 0);

    if (dev->header == SHT40_NAK) return SHT40_NOK;

    dev->controlReg &= ~(SHT40_OLD_RH | SHT40_OLD_TEMP);
    return SHT40_OK;
}

uint8_t SHT40_temperature(SHT40 *dev, int8_t *out)
{
    uint8_t ret = SHT40_OK;

    if (!dev->mData.temp[0] && !dev->mData.temp[1]) return SHT40_NOK;
    if (dev->controlReg & SHT40_OLD_TEMP) ret = SHT40_OLD_DATA;

    if (SHT40_getUnit(dev) == SHT40_UNIT_C)
        *out = -45 + (175 * ((dev->mData.temp[0] << 8) | dev->mData.temp[1]) / 655) / 100;
    else
        *out = -49 + (315 * (((dev->mData.temp[0] << 8) | dev->mData.temp[1]) / 655)) / 100;

    dev->controlReg |= SHT40_OLD_TEMP;
    return ret;
}

uint8_t SHT40_rh(SHT40 *dev, uint8_t *out)
{
    uint8_t ret = SHT40_OK;

    if (!dev->mData.rh[0] && !dev->mData.rh[1]) return SHT40_NOK;
    if (dev->controlReg & SHT40_OLD_RH) ret = SHT40_OLD_DATA;

    *out = -6 + (125 * (((dev->mData.rh[0] << 8) | dev->mData.rh[1]) / 655)) / 100;

    if (*out > 100) *out = 100;
    else if (*out < 0) *out = 0;

    dev->controlReg |= SHT40_OLD_RH;
    return ret;
}

uint32_t SHT40_whoAmI(SHT40 *dev)
{
    uint8_t cmd = SHT40_SN;
    dev->I2CWrite(dev->address, &cmd, 1, 1);
    dev->I2CRead(dev->address, (uint8_t*)&dev->snData, 6, 0);

    if (dev->header == SHT40_NAK) return SHT40_NOK;
    return ((dev->snData.sn1 << 16) | dev->snData.sn2);
}

void SHT40_reset(const SHT40 *dev)
{
    uint8_t cmd = SHT40_RST;
    dev->I2CWrite(dev->address, &cmd, 1, 0);
}

uint8_t SHT40_begin(SHT40 *dev, SHT40_unit_t u)
{
    if (!dev->I2CRead) return SHT40_I2CH_R;
    if (!dev->I2CWrite) return SHT40_I2CH_W;

    SHT40_setUnit(dev, u);

    uint32_t tmp = SHT40_whoAmI(dev);
    if (!tmp || tmp == 0xFFFFFFFF) return SHT40_NOK;

    return SHT40_OK;
}

void SHT40_setUnit(SHT40 *dev, SHT40_unit_t unit)
{
    dev->controlReg &= ~SHT40_UNIT;
    dev->controlReg |= (unit << SHT40_UNIT_POS);
}

SHT40_unit_t SHT40_getUnit(const SHT40 *dev)
{
    return (SHT40_unit_t)(dev->controlReg & SHT40_UNIT);
}

void SHT40_clear(SHT40 *dev)
{
    memset(&dev->mData, 0, sizeof(dev->mData));
    dev->controlReg &= ~(SHT40_OLD_RH | SHT40_OLD_TEMP);
}


// ----- STATIC FUNCTION DEFINITIONS
static uint16_t getMeasureDelay(SHT40_meas_t type)
{
    switch (type) {
        case TRH_H: return 9;
        case TRH_M: return 5;
        case TRH_L: return 2;
        case TRH_H_H02W1S:
        case TRH_H_H011W1S:
        case TRH_H_H002W1S: return 1150;
        case TRH_H_H02W01S:
        case TRH_H_H011W01S:
        case TRH_H_H002W01S: return 120;
        default: break;
    }
    return 1;
}
