#ifndef __BLOOD_OXYGEN_H__
#define __BLOOD_OXYGEN_H__

/* VERY IMPORTANT */
#include "main.h"   // <-- THIS FIXES EVERYTHING

#define BO_I2C_ADDR        (0x57 << 1)
#define BO_REG_HR_SPO2     0x0C
#define BO_REG_CTRL        0x20

typedef struct
{
    int32_t heart_rate;
    int32_t spo2;
} BO_Data_t;

HAL_StatusTypeDef BO_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef BO_Start(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef BO_Stop(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef BO_ReadHRSpO2(I2C_HandleTypeDef *hi2c, BO_Data_t *data);
HAL_StatusTypeDef BO_PrintUSART(UART_HandleTypeDef *huart, BO_Data_t *data);

#endif
