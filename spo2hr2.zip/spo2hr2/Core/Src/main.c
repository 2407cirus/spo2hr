/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "blood_oxygen.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
BO_Data_t bo_data;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define VALID_STABLE_COUNT   5   // discard first 5 valid frames
static uint8_t valid_stable_cnt = 0;

#define HR_MIN_DETECT     40
#define HR_MAX_DETECT     180
#define SPO2_MIN_DETECT   85
#define SPO2_MAX_DETECT   100

static uint32_t last_valid_tick = 0;
#define FINGER_TIMEOUT_MS   3000   // 3 seconds
#define FINGER_LOST_TIMEOUT 3000  // 3 seconds
static uint32_t last_print_tick = 0;
#define PRINT_INTERVAL_MS   5000   // 5 seconds

#define FINGER_LOST_LIMIT     5
#define FINGER_DETECT_LIMIT   3

static uint8_t finger_lost_cnt   = 0;
static uint8_t finger_detect_cnt = 0;
#define HR_MIN_VALID        40
#define HR_MAX_VALID        180
#define SPO2_MIN_VALID      80
#define SPO2_MAX_VALID      100

#define POST_STABLE_HOLD    10   // 10 × 200ms = 2 seconds
static uint8_t invalid_hold_cnt = 0;


#define BO_AVG_COUNT        5
#define BO_WARMUP_CNT       10
#define BO_STABLE_CNT       5

typedef enum
{
    BO_NO_FINGER = 0,
    BO_SCANNING,
    BO_STABLE
} BO_State_t;

static BO_State_t bo_state = BO_NO_FINGER;
//static BO_State_t bo_state = BO_NO_FINGER;

/* -------- Counters -------- */
//static uint8_t finger_detect_cnt = 0;
//static uint8_t finger_lost_cnt   = 0;
static uint8_t warmup_counter    = 0;
static uint8_t stable_counter    = 0;
//static uint8_t invalid_hold_cnt  = 0;

/* -------- Filter buffers -------- */
static int hr_buf[BO_AVG_COUNT]   = {0};
static int spo2_buf[BO_AVG_COUNT] = {0};
static uint8_t avg_index = 0;

/* -------- Reset helper -------- */
static void BO_ResetAll(void)
{
    valid_stable_cnt = 0;

    finger_detect_cnt = 0;
    finger_lost_cnt   = 0;
    warmup_counter    = 0;
    stable_counter    = 0;
    invalid_hold_cnt  = 0;
    avg_index         = 0;
    last_print_tick   = 0;

    for (int i = 0; i < BO_AVG_COUNT; i++)
    {
        hr_buf[i]   = 0;
        spo2_buf[i] = 0;
    }
}

//static int hr_buf[BO_AVG_COUNT];
//static int spo2_buf[BO_AVG_COUNT];
//static uint8_t avg_index = 0;

//static uint8_t warmup_counter = 0;
//static uint8_t stable_counter = 0;
/* USER CODE END 0 */


/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  BO_Init(&hi2c1);
  BO_Start(&hi2c1);
  HAL_Delay(1000);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	  /* USER CODE BEGIN 3 */
	  if (BO_ReadHRSpO2(&hi2c1, &bo_data) == HAL_OK)
	  {
	      switch (bo_state)
	      {
	          /* ---------------- NO FINGER ---------------- */
	      case BO_NO_FINGER:
	      {
	          /* Strong finger detection condition */
	          if (bo_data.heart_rate >= HR_MIN_DETECT &&
	              bo_data.heart_rate <= HR_MAX_DETECT &&
	              bo_data.spo2       >= SPO2_MIN_DETECT &&
	              bo_data.spo2       <= SPO2_MAX_DETECT)
	          {
	              finger_detect_cnt++;

	              if (finger_detect_cnt >= FINGER_DETECT_LIMIT)
	              {
	                  /* CONFIRMED finger presence */
	                  finger_detect_cnt = 0;
	                  warmup_counter    = 0;
	                  avg_index         = 0;
	                  last_valid_tick   = HAL_GetTick();

	                  bo_state = BO_SCANNING;

	                  const char *msg = "Finger detected. Scanning...\r\n";
	                  HAL_UART_Transmit(&huart2,
	                                    (uint8_t *)msg,
	                                    strlen(msg),
	                                    HAL_MAX_DELAY);
	              }
	          }
	          else
	          {
	              /* Reset detection counter on noise */
	              finger_detect_cnt = 0;
	          }
	      }
	      break;



	          /* ---------------- SCANNING ---------------- */
	          case BO_SCANNING:
	        	  if (bo_data.heart_rate <= 0 && bo_data.spo2 <= 0)
	        	  {
	        	      BO_ResetAll();
	        	      bo_state = BO_NO_FINGER;
	        	      break;
	        	  }


	              if (++warmup_counter >= BO_WARMUP_CNT)
	              {
	                  bo_state = BO_STABLE;
	                  stable_counter = 0;

	                  const char *msg = "Signal stable. Measuring...\r\n";
	                  HAL_UART_Transmit(&huart2,
	                                    (uint8_t *)msg,
	                                    strlen(msg),
	                                    HAL_MAX_DELAY);
	              }
	              break;

	          case BO_STABLE:
	          {
	              /* Strict validity check */
	              if (bo_data.heart_rate >= HR_MIN_VALID &&
	                  bo_data.heart_rate <= HR_MAX_VALID &&
	                  bo_data.spo2       >= SPO2_MIN_VALID &&
	                  bo_data.spo2       <= SPO2_MAX_VALID)
	              {
	                  last_valid_tick = HAL_GetTick();

	                  /* Ignore first few valid frames */
	                  if (valid_stable_cnt < VALID_STABLE_COUNT)
	                  {
	                      valid_stable_cnt++;
	                      break;
	                  }

	                  /* PRINT EVERY 5 SECONDS */
	                  if (HAL_GetTick() - last_print_tick >= PRINT_INTERVAL_MS)
	                  {
	                      last_print_tick = HAL_GetTick();
	                      BO_PrintUSART(&huart2, &bo_data);
	                  }
	              }
	              else
	              {
	                  /* Finger removal */
	                  if ((HAL_GetTick() - last_valid_tick) > FINGER_LOST_TIMEOUT)
	                  {
	                      BO_ResetAll();
	                      bo_state = BO_NO_FINGER;

	                      const char *msg = "Finger removed.\r\n";
	                      HAL_UART_Transmit(&huart2,
	                                        (uint8_t *)msg,
	                                        strlen(msg),
	                                        HAL_MAX_DELAY);
	                  }
	              }
	          }
	          break;






	      }
	  }

	  HAL_Delay(200);


	  /* USER CODE END 3 */

    /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = 64;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV1;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10707DBC;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
