#include "blood_oxygen.h"
#include <stdio.h>
#include <string.h>

HAL_StatusTypeDef BO_Init(I2C_HandleTypeDef *hi2c)
{
    uint8_t dummy;
    return HAL_I2C_Master_Receive(hi2c, BO_I2C_ADDR, &dummy, 1, 100);
}

HAL_StatusTypeDef BO_Start(I2C_HandleTypeDef *hi2c)
{
    uint8_t cmd[2] = {0x00, 0x01};
    return HAL_I2C_Mem_Write(
        hi2c,
        BO_I2C_ADDR,
        BO_REG_CTRL,
        I2C_MEMADD_SIZE_8BIT,
        cmd,
        2,
        100
    );
}

HAL_StatusTypeDef BO_Stop(I2C_HandleTypeDef *hi2c)
{
    uint8_t cmd[2] = {0x00, 0x02};
    return HAL_I2C_Mem_Write(
        hi2c,
        BO_I2C_ADDR,
        BO_REG_CTRL,
        I2C_MEMADD_SIZE_8BIT,
        cmd,
        2,
        100
    );
}

HAL_StatusTypeDef BO_ReadHRSpO2(I2C_HandleTypeDef *hi2c, BO_Data_t *data)
{
    uint8_t buf[8];

    if (HAL_I2C_Mem_Read(
            hi2c,
            BO_I2C_ADDR,
            BO_REG_HR_SPO2,
            I2C_MEMADD_SIZE_8BIT,
            buf,
            8,
            200) != HAL_OK)
    {
        return HAL_ERROR;
    }

    data->spo2 = buf[0];
    if (data->spo2 == 0)
        data->spo2 = -1;

    data->heart_rate =
        ((uint32_t)buf[2] << 24) |
        ((uint32_t)buf[3] << 16) |
        ((uint32_t)buf[4] << 8)  |
        ((uint32_t)buf[5]);

    if (data->heart_rate == 0)
        data->heart_rate = -1;

    return HAL_OK;
}

HAL_StatusTypeDef BO_PrintUSART(UART_HandleTypeDef *huart, BO_Data_t *data)
{
    char msg[64];
    int len = snprintf(msg, sizeof(msg),
                       "SPO2:%ld HR:%ld\r\n",
                       data->spo2,
                       data->heart_rate);

    return HAL_UART_Transmit(
        huart,
        (uint8_t *)msg,
        len,
        100
    );
}
